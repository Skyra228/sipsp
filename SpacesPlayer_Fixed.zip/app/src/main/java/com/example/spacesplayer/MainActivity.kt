package com.example.spacesplayer

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder

data class AudioTrack(val title: String, val url: String)

class MainActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private val httpClient = OkHttpClient.Builder().followRedirects(true).build()
    private val trackList = ArrayList<AudioTrack>()
    private lateinit var adapter: ArrayAdapter<String>
    private var currentIndex = -1

    private val SPACES_BASE = "https://spaces.im"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        player = ExoPlayer.Builder(this).build()

        val etSearch = findViewById<EditText>(R.id.etSearch)
        val btnSearch = findViewById<Button>(R.id.btnSearch)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val tvCurrentTrack = findViewById<TextView>(R.id.tvCurrentTrack)
        val btnPlayPause = findViewById<Button>(R.id.btnPlayPause)
        val lvTracks = findViewById<ListView>(R.id.lvTracks)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        lvTracks.adapter = adapter

        btnPlayPause.setOnClickListener {
            if (player.isPlaying) {
                player.pause()
                btnPlayPause.text = "Играть"
            } else {
                player.play()
                btnPlayPause.text = "Пауза"
            }
        }

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    if (currentIndex + 1 < trackList.size) {
                        playTrack(currentIndex + 1, tvCurrentTrack, btnPlayPause)
                    }
                }
            }
        })

        findViewById<Button>(R.id.btnClub).setOnClickListener { searchSpaces("Клубняк 2008", tvStatus) }
        findViewById<Button>(R.id.btnBass).setOnClickListener { searchSpaces("Басы в тачку", tvStatus) }
        findViewById<Button>(R.id.btnRap).setOnClickListener { searchSpaces("Русский рэп", tvStatus) }
        findViewById<Button>(R.id.btnRock).setOnClickListener { searchSpaces("Русский рок", tvStatus) }

        btnSearch.setOnClickListener {
            val q = etSearch.text.toString().trim()
            if (q.isNotEmpty()) searchSpaces(q, tvStatus)
        }

        lvTracks.setOnItemClickListener { _, _, position, _ ->
            playTrack(position, tvCurrentTrack, btnPlayPause)
        }
    }

    private fun searchSpaces(query: String, tvStatus: TextView) {
        tvStatus.text = "Ищем '$query' на Spaces..."

        CoroutineScope(Dispatchers.IO).launch {
            val foundTracks = ArrayList<AudioTrack>()
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val searchUrl = "$SPACES_BASE/mysite/find/?search=$encoded&type=music"

                val req = Request.Builder()
                    .url(searchUrl)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) Chrome/120.0.0.0 Mobile")
                    .build()

                val html = httpClient.newCall(req).execute().body?.string() ?: ""
                val doc = Jsoup.parse(html)

                val items = doc.select(".main_item, .f-item, li, tr, div")

                for (item in items) {
                    var streamUrl = ""
                    val audioTag = item.selectFirst("audio, audio source")
                    if (audioTag != null) {
                        streamUrl = audioTag.attr("src").ifEmpty { audioTag.attr("data-src") }
                    } else {
                        val dl = item.selectFirst("a[href*=.mp3], a[href*=download]")
                        if (dl != null) streamUrl = dl.attr("href")
                    }

                    if (streamUrl.isNotEmpty()) {
                        if (streamUrl.startsWith("//")) streamUrl = "https:$streamUrl"
                        else if (streamUrl.startsWith("/")) streamUrl = SPACES_BASE + streamUrl

                        val titleTag = item.selectFirst("a, span")
                        var title = titleTag?.text()?.trim() ?: "Аудиозапись"
                        title = title.replace(Regex("\.mp3$", RegexOption.IGNORE_CASE), "")

                        if (foundTracks.none { it.url == streamUrl }) {
                            foundTracks.add(AudioTrack(title, streamUrl))
                        }
                    }
                    if (foundTracks.size >= 25) break
                }

                withContext(Dispatchers.Main) {
                    trackList.clear()
                    adapter.clear()
                    if (foundTracks.isNotEmpty()) {
                        trackList.addAll(foundTracks)
                        adapter.addAll(foundTracks.map { "▶ " + it.title })
                        tvStatus.text = "Найдено треков: ${foundTracks.size}"
                    } else {
                        tvStatus.text = "Ничего не найдено."
                    }
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    tvStatus.text = "Ошибка соединения со Spaces."
                }
            }
        }
    }

    private fun playTrack(index: Int, tvCurrent: TextView, btnPlay: Button) {
        if (index !in trackList.indices) return
        currentIndex = index
        val track = trackList[index]

        tvCurrent.text = track.title
        btnPlay.text = "Пауза"

        val mediaItem = MediaItem.fromUri(track.url)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.play()
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
